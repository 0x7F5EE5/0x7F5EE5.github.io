function EFServer() {
    //Todo: write mod that disables rendering engine, autodisplays gui, and makes run server button.
    console.log("hello world");
}