# EaglerForgeInjector
A modding API injector for vanilla eaglercraft builds.

### How to use:
#### Online
Go to https://eaglerforge.github.io/EaglerForgeInjector/ and upload an unminified, unobfuscated, unsigned EaglercraftX offline download.

#### Portable Offline
Download this repository as a .zip, and extract it. Open index.html with your preferred browser (use `ctrl` + `O` on a new tab) and upload an unminified, unobfuscated, unsigned EaglercraftX offline download.