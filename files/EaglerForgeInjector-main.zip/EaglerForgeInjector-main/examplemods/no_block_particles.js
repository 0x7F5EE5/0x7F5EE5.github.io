ModAPI.hooks.methods[
    ModAPI.util.getMethodFromPackage(
        "net.minecraft.client.particles.EffectRenderer",
        "addBlockDestroyEffects"
    )
] = () => {}