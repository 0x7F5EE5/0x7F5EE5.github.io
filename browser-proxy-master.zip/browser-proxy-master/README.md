browser-proxy
=============

what?
-----

    MIGRATORATOR_AUTH=foo:bar node proxy.js